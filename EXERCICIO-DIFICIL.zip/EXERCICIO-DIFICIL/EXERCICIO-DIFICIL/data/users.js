// Dados em memória para usuários
let users = [
    {
        id: 1,
        name: 'João Silva',
        email: 'joao@email.com',
        age: 30,
        active: true,
        createdAt: '2024-01-15T10:30:00.000Z',
        updatedAt: '2024-01-15T10:30:00.000Z'
    },
    {
        id: 2,
        name: 'Maria Santos',
        email: 'maria@email.com',
        age: 25,
        active: true,
        createdAt: '2024-01-16T14:20:00.000Z',
        updatedAt: '2024-01-16T14:20:00.000Z'
    },
    {
        id: 3,
        name: 'Pedro Costa',
        email: 'pedro@email.com',
        age: 35,
        active: false,
        createdAt: '2024-01-17T09:15:00.000Z',
        updatedAt: '2024-01-20T16:45:00.000Z'
    }
];

// Contador para gerar IDs únicos
let nextUserId = 4;

// Função para gerar próximo ID
function getNextUserId() {
    return nextUserId++;
}

// Função para encontrar usuário por ID
function findUserById(id) {
    return users.find(user => user.id === parseInt(id));
}

// Função para encontrar usuário por email
function findUserByEmail(email) {
    return users.find(user => user.email.toLowerCase() === email.toLowerCase());
}

// Função para validar dados do usuário
function validateUserData(userData) {
    const errors = [];

    if (!userData.name || typeof userData.name !== 'string' || userData.name.trim().length < 2) {
        errors.push('Nome é obrigatório e deve ter pelo menos 2 caracteres');
    }

    if (!userData.email || typeof userData.email !== 'string') {
        errors.push('Email é obrigatório');
    } else {
        const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
        if (!emailRegex.test(userData.email)) {
            errors.push('Email deve ter um formato válido');
        }
    }

    if (userData.age !== undefined) {
        if (typeof userData.age !== 'number' || userData.age < 0 || userData.age > 120) {
            errors.push('Idade deve ser um número entre 0 e 120');
        }
    }

    if (userData.active !== undefined && typeof userData.active !== 'boolean') {
        errors.push('Active deve ser um valor booleano');
    }

    return errors;
}

// Função para criar novo usuário
function createUser(userData) {
    const errors = validateUserData(userData);
    if (errors.length > 0) {
        throw new Error(errors.join(', '));
    }

    // Verificar se email já existe
    if (findUserByEmail(userData.email)) {
        throw new Error('Email já está em uso');
    }

    const newUser = {
        id: getNextUserId(),
        name: userData.name.trim(),
        email: userData.email.toLowerCase().trim(),
        age: userData.age || null,
        active: userData.active !== undefined ? userData.active : true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };

    users.push(newUser);
    return newUser;
}

// Função para atualizar usuário
function updateUser(id, userData) {
    const user = findUserById(id);
    if (!user) {
        throw new Error('Usuário não encontrado');
    }

    // Validar apenas os campos que estão sendo atualizados
    const updateData = {};
    if (userData.name !== undefined) updateData.name = userData.name;
    if (userData.email !== undefined) updateData.email = userData.email;
    if (userData.age !== undefined) updateData.age = userData.age;
    if (userData.active !== undefined) updateData.active = userData.active;

    const errors = validateUserData(updateData);
    if (errors.length > 0) {
        throw new Error(errors.join(', '));
    }

    // Verificar se email já existe (exceto para o próprio usuário)
    if (updateData.email && updateData.email !== user.email) {
        const existingUser = findUserByEmail(updateData.email);
        if (existingUser && existingUser.id !== user.id) {
            throw new Error('Email já está em uso');
        }
    }

    // Atualizar campos
    if (updateData.name) user.name = updateData.name.trim();
    if (updateData.email) user.email = updateData.email.toLowerCase().trim();
    if (updateData.age !== undefined) user.age = updateData.age;
    if (updateData.active !== undefined) user.active = updateData.active;
    user.updatedAt = new Date().toISOString();

    return user;
}

// Função para deletar usuário
function deleteUser(id) {
    const userIndex = users.findIndex(user => user.id === parseInt(id));
    if (userIndex === -1) {
        throw new Error('Usuário não encontrado');
    }

    const deletedUser = users.splice(userIndex, 1)[0];
    return deletedUser;
}

// Função para obter estatísticas dos usuários
function getUserStats() {
    return {
        total: users.length,
        active: users.filter(user => user.active).length,
        inactive: users.filter(user => !user.active).length,
        averageAge: users.length > 0 ? 
            Math.round(users.filter(user => user.age).reduce((sum, user) => sum + user.age, 0) / users.filter(user => user.age).length) : 0
    };
}

module.exports = {
    users,
    getNextUserId,
    findUserById,
    findUserByEmail,
    validateUserData,
    createUser,
    updateUser,
    deleteUser,
    getUserStats
};