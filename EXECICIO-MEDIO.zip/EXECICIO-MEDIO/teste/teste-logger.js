/**
 * Exercício 11: Teste do Gerador de Logs
 * Arquivo de teste para demonstrar todas as funcionalidades do sistema de logging
 * 
 * Para executar: node teste-logger.js
 */

const logger = require('./logger');

console.log('?? Iniciando testes do sistema de logging...\n');

// Função para aguardar um tempo (para demonstração)
function aguardar(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Função principal de teste
async function executarTestes() {
    try {
        console.log('?? TESTE 1: Logs básicos com diferentes níveis');
        console.log('?'.repeat(50));
        
        // Testar todos os níveis de log
        logger.info('Sistema iniciado com sucesso');
        await aguardar(100);
        
        logger.warn('Memória em 80% de uso');
        await aguardar(100);
        
        logger.error('Falha na conexão com o banco de dados');
        await aguardar(100);
        
        logger.success('Backup realizado com sucesso');
        await aguardar(100);
        
        console.log('\n?? TESTE 2: Usando a função log() diretamente');
        console.log('?'.repeat(50));
        
        logger.log('Processando dados...', 'INFO');
        await aguardar(100);
        
        logger.log('Cache limpo', 'SUCCESS');
        await aguardar(100);
        
        console.log('\n?? TESTE 3: Testando validação de entrada');
        console.log('?'.repeat(50));
        
        // Testar mensagem vazia (deve gerar erro)
        try {
            logger.log('', 'INFO');
        } catch (error) {
            console.log('? Validação funcionando: mensagem vazia rejeitada');
        }
        
        // Testar nível inválido (deve gerar erro)
        try {
            logger.log('Teste', 'INVALID');
        } catch (error) {
            console.log('? Validação funcionando: nível inválido rejeitado');
        }
        
        console.log('\n?? TESTE 4: Simulando cenário real de aplicação');
        console.log('?'.repeat(50));
        
        // Simular início de aplicação
        logger.info('?? Aplicação iniciando...');
        await aguardar(200);
        
        logger.info('?? Carregando configurações...');
        await aguardar(300);
        
        logger.success('? Configurações carregadas');
        await aguardar(200);
        
        logger.info('?? Conectando ao banco de dados...');
        await aguardar(400);
        
        logger.success('? Conexão estabelecida');
        await aguardar(200);
        
        logger.warn('?? Pool de conexões em 70%');
        await aguardar(300);
        
        logger.info('?? Usuário admin logou no sistema');
        await aguardar(200);
        
        logger.error('? Falha ao enviar email de notificação');
        await aguardar(300);
        
        logger.info('?? Tentando reenvio...');
        await aguardar(500);
        
        logger.success('? Email enviado com sucesso');
        await aguardar(200);
        
        console.log('\n?? TESTE 5: Listando arquivos de log');
        console.log('?'.repeat(50));
        
        logger.listarArquivosLog();
        
        console.log('\n?? TESTE 6: Lendo logs do dia atual');
        console.log('?'.repeat(50));
        
        logger.exibirLogs();
        
        console.log('\n?? TESTE 7: Filtrando logs por nível');
        console.log('?'.repeat(50));
        
        console.log('\n?? Apenas logs de ERROR:');
        logger.exibirLogs({ nivel: 'ERROR' });
        
        console.log('\n?? Apenas logs de SUCCESS:');
        logger.exibirLogs({ nivel: 'SUCCESS' });
        
        console.log('\n?? Apenas logs de WARN:');
        logger.exibirLogs({ nivel: 'WARN' });
        
        console.log('\n?? TESTE 8: Demonstração de uso em diferentes contextos');
        console.log('?'.repeat(50));
        
        // Simular logs de diferentes módulos
        logger.info('[AUTH] Tentativa de login para usuário: admin');
        logger.success('[AUTH] Login realizado com sucesso');
        
        logger.info('[API] Requisição GET /api/users');
        logger.warn('[API] Rate limit atingido para IP 192.168.1.100');
        
        logger.info('[DB] Executando query: SELECT * FROM users');
        logger.error('[DB] Timeout na consulta após 30 segundos');
        
        logger.info('[CACHE] Limpando cache expirado');
        logger.success('[CACHE] 150 entradas removidas');
        
        console.log('\n?? TESTE 9: Logs com informações técnicas');
        console.log('?'.repeat(50));
        
        logger.info(`Memória utilizada: ${Math.round(Math.random() * 100)}%`);
        logger.info(`CPU: ${Math.round(Math.random() * 100)}%`);
        logger.info(`Uptime: ${Math.round(Math.random() * 24)}h ${Math.round(Math.random() * 60)}m`);
        
        const usuarios = Math.round(Math.random() * 1000);
        logger.info(`Usuários online: ${usuarios}`);
        
        if (usuarios > 800) {
            logger.warn('Alto número de usuários conectados');
        }
        
        console.log('\n?? TESTE 10: Finalizando demonstração');
        console.log('?'.repeat(50));
        
        logger.success('?? Todos os testes executados com sucesso!');
        logger.info('?? Verifique a pasta "logs" para ver os arquivos gerados');
        logger.info('?? Use as funções lerLogs() e exibirLogs() para consultar logs');
        
        console.log('\n? Demonstração concluída!');
        console.log('?? Consulte o README.md para mais informações sobre o uso.');
        
    } catch (error) {
        logger.error(`Erro durante os testes: ${error.message}`);
        console.error('? Falha na execução dos testes:', error);
    }
}

// Função para demonstrar uso avançado
function demonstrarUsoAvancado() {
    console.log('\n?? DEMONSTRAÇÃO DE USO AVANÇADO');
    console.log('?'.repeat(60));
    
    // Exemplo de como usar em uma aplicação real
    console.log('\n?? Exemplo de integração em aplicação:');
    console.log(`
// Em um arquivo de configuração
const logger = require('./logger');

// Em um middleware Express
app.use((req, res, next) => {
    logger.info(\`\${req.method} \${req.url} - IP: \${req.ip}\`);
    next();
});

// Em um handler de erro
app.use((err, req, res, next) => {
    logger.error(\`Erro: \${err.message} - Stack: \${err.stack}\`);
    res.status(500).json({ error: 'Erro interno do servidor' });
});

// Em operações de banco de dados
async function buscarUsuario(id) {
    try {
        logger.info(\`Buscando usuário com ID: \${id}\`);
        const usuario = await db.findById(id);
        logger.success(\`Usuário encontrado: \${usuario.email}\`);
        return usuario;
    } catch (error) {
        logger.error(\`Erro ao buscar usuário \${id}: \${error.message}\`);
        throw error;
    }
}
    `);
    
    console.log('\n?? Exemplo de monitoramento:');
    console.log(`
// Monitoramento de performance
setInterval(() => {
    const memUsage = process.memoryUsage();
    const memMB = Math.round(memUsage.heapUsed / 1024 / 1024);
    
    if (memMB > 100) {
        logger.warn(\`Alto uso de memória: \${memMB}MB\`);
    } else {
        logger.info(\`Uso de memória: \${memMB}MB\`);
    }
}, 60000); // A cada minuto
    `);
}

// Executar testes se o arquivo for executado diretamente
if (require.main === module) {
    console.log('?? Executando demonstração completa do sistema de logging...\n');
    
    executarTestes()
        .then(() => {
            demonstrarUsoAvancado();
            console.log('\n?? Demonstração finalizada!');
        })
        .catch(error => {
            console.error('? Erro na demonstração:', error);
        });
}

// Exportar funções para uso em outros arquivos
module.exports = {
    executarTestes,
    demonstrarUsoAvancado
};