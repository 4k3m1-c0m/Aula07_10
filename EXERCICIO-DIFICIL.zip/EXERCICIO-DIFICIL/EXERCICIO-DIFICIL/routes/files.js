const express = require('express');
const router = express.Router();

// Importar funções de dados dos arquivos
const {
    files,
    findFileById,
    findFilesByUserId,
    uploadFile,
    deleteFile,
    getFileStats,
    filterFiles,
    formatFileSize
} = require('../data/files');

// Importar função para verificar se usuário existe
const { findUserById } = require('../data/users');

// ===== ROTAS DE ARQUIVOS =====

// GET /api/files - Listar todos os arquivos
router.get('/', (req, res) => {
    try {
        const { userId, mimetype, minSize, maxSize, search, sortBy = 'uploadedAt', order = 'desc', limit, offset } = req.query;
        
        // Aplicar filtros
        const filteredFiles = filterFiles({
            userId,
            mimetype,
            minSize,
            maxSize,
            search
        });

        // Ordenar resultados
        filteredFiles.sort((a, b) => {
            let valueA = a[sortBy];
            let valueB = b[sortBy];

            if (sortBy.includes('At')) {
                valueA = new Date(valueA);
                valueB = new Date(valueB);
            } else if (typeof valueA === 'string') {
                valueA = valueA.toLowerCase();
                valueB = valueB.toLowerCase();
            }

            if (order === 'desc') {
                return valueA < valueB ? 1 : -1;
            } else {
                return valueA > valueB ? 1 : -1;
            }
        });

        // Paginação
        const startIndex = offset ? parseInt(offset) : 0;
        const endIndex = limit ? startIndex + parseInt(limit) : filteredFiles.length;
        const paginatedFiles = filteredFiles.slice(startIndex, endIndex);

        // Adicionar informações formatadas
        const filesWithFormattedSize = paginatedFiles.map(file => ({
            ...file,
            formattedSize: formatFileSize(file.size)
        }));

        res.json({
            success: true,
            data: filesWithFormattedSize,
            pagination: {
                total: filteredFiles.length,
                offset: startIndex,
                limit: limit ? parseInt(limit) : filteredFiles.length,
                hasMore: endIndex < filteredFiles.length
            },
            filters: {
                userId,
                mimetype,
                minSize,
                maxSize,
                search,
                sortBy,
                order
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao listar arquivos',
            error: error.message
        });
    }
});

// GET /api/files/stats - Obter estatísticas dos arquivos
router.get('/stats', (req, res) => {
    try {
        const stats = getFileStats();
        
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao obter estatísticas',
            error: error.message
        });
    }
});

// GET /api/files/user/:userId - Listar arquivos de um usuário específico
router.get('/user/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        
        // Verificar se usuário existe
        const user = findUserById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado',
                userId: parseInt(userId)
            });
        }

        const userFiles = findFilesByUserId(userId);
        
        // Adicionar informações formatadas
        const filesWithFormattedSize = userFiles.map(file => ({
            ...file,
            formattedSize: formatFileSize(file.size)
        }));

        res.json({
            success: true,
            data: filesWithFormattedSize,
            user: {
                id: user.id,
                name: user.name,
                email: user.email
            },
            summary: {
                totalFiles: userFiles.length,
                totalSize: userFiles.reduce((sum, file) => sum + file.size, 0),
                totalSizeFormatted: formatFileSize(userFiles.reduce((sum, file) => sum + file.size, 0))
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar arquivos do usuário',
            error: error.message
        });
    }
});

// GET /api/files/:id - Obter arquivo específico
router.get('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const file = findFileById(id);

        if (!file) {
            return res.status(404).json({
                success: false,
                message: 'Arquivo não encontrado',
                id: parseInt(id)
            });
        }

        // Buscar informações do usuário
        const user = findUserById(file.userId);

        res.json({
            success: true,
            data: {
                ...file,
                formattedSize: formatFileSize(file.size),
                user: user ? {
                    id: user.id,
                    name: user.name,
                    email: user.email
                } : null
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao buscar arquivo',
            error: error.message
        });
    }
});

// POST /api/files - Simular upload de arquivo
router.post('/', (req, res) => {
    try {
        const fileData = req.body;

        // Validação básica de entrada
        if (!fileData || Object.keys(fileData).length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Dados do arquivo são obrigatórios'
            });
        }

        // Verificar se usuário existe
        if (fileData.userId) {
            const user = findUserById(fileData.userId);
            if (!user) {
                return res.status(404).json({
                    success: false,
                    message: 'Usuário não encontrado',
                    userId: fileData.userId
                });
            }
        }

        const newFile = uploadFile(fileData);

        res.status(201).json({
            success: true,
            message: 'Arquivo enviado com sucesso (simulação)',
            data: {
                ...newFile,
                formattedSize: formatFileSize(newFile.size)
            }
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: 'Erro ao enviar arquivo',
            error: error.message
        });
    }
});

// DELETE /api/files/:id - Deletar arquivo
router.delete('/:id', (req, res) => {
    try {
        const { id } = req.params;
        const deletedFile = deleteFile(id);

        res.json({
            success: true,
            message: 'Arquivo deletado com sucesso',
            data: {
                ...deletedFile,
                formattedSize: formatFileSize(deletedFile.size)
            }
        });
    } catch (error) {
        if (error.message === 'Arquivo não encontrado') {
            return res.status(404).json({
                success: false,
                message: error.message,
                id: parseInt(req.params.id)
            });
        }

        res.status(500).json({
            success: false,
            message: 'Erro ao deletar arquivo',
            error: error.message
        });
    }
});

// GET /api/files/download/:id - Simular download de arquivo
router.get('/download/:id', (req, res) => {
    try {
        const { id } = req.params;
        const file = findFileById(id);

        if (!file) {
            return res.status(404).json({
                success: false,
                message: 'Arquivo não encontrado',
                id: parseInt(id)
            });
        }

        // Simular download (na vida real, seria um stream do arquivo)
        res.json({
            success: true,
            message: 'Download iniciado (simulação)',
            data: {
                id: file.id,
                filename: file.filename,
                originalName: file.originalName,
                mimetype: file.mimetype,
                size: file.size,
                formattedSize: formatFileSize(file.size),
                downloadUrl: `${req.protocol}://${req.get('host')}/uploads/${file.filename}`,
                downloadStarted: new Date().toISOString()
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao iniciar download',
            error: error.message
        });
    }
});

// GET /api/files/types/summary - Resumo por tipos de arquivo
router.get('/types/summary', (req, res) => {
    try {
        const stats = getFileStats();
        
        res.json({
            success: true,
            data: {
                totalFiles: stats.total,
                totalSize: stats.totalSize,
                totalSizeFormatted: formatFileSize(stats.totalSize),
                averageSize: stats.averageSize,
                averageSizeFormatted: formatFileSize(stats.averageSize),
                mimetypes: stats.mimetypes,
                byMimetype: stats.byMimetype.map(item => ({
                    ...item,
                    percentage: Math.round((item.count / stats.total) * 100)
                }))
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro ao obter resumo por tipos',
            error: error.message
        });
    }
});

// POST /api/files/bulk-upload - Simular upload múltiplo
router.post('/bulk-upload', (req, res) => {
    try {
        const { files: filesList, userId } = req.body;

        if (!filesList || !Array.isArray(filesList) || filesList.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Lista de arquivos é obrigatória'
            });
        }

        if (!userId) {
            return res.status(400).json({
                success: false,
                message: 'ID do usuário é obrigatório'
            });
        }

        // Verificar se usuário existe
        const user = findUserById(userId);
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuário não encontrado',
                userId: userId
            });
        }

        const uploadedFiles = [];
        const errors = [];

        filesList.forEach((fileData, index) => {
            try {
                const newFile = uploadFile({ ...fileData, userId });
                uploadedFiles.push({
                    ...newFile,
                    formattedSize: formatFileSize(newFile.size)
                });
            } catch (error) {
                errors.push({
                    index,
                    filename: fileData.originalName || 'Desconhecido',
                    error: error.message
                });
            }
        });

        res.status(201).json({
            success: true,
            message: `Upload múltiplo concluído: ${uploadedFiles.length} sucessos, ${errors.length} erros`,
            data: {
                uploaded: uploadedFiles,
                errors: errors,
                summary: {
                    totalAttempted: filesList.length,
                    successful: uploadedFiles.length,
                    failed: errors.length,
                    totalSize: uploadedFiles.reduce((sum, file) => sum + file.size, 0),
                    totalSizeFormatted: formatFileSize(uploadedFiles.reduce((sum, file) => sum + file.size, 0))
                }
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Erro no upload múltiplo',
            error: error.message
        });
    }
});

module.exports = router;