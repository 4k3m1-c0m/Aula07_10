/**
 * Exercício 11: Gerador de Logs
 * Sistema completo de logging com cores, timestamps e salvamento em arquivos
 * 
 * Funcionalidades:
 * - Logs coloridos no console
 * - Timestamps formatados
 * - Salvamento automático em arquivos por data
 * - Validação de mensagens e níveis
 * - Leitura de logs com filtros
 */

const fs = require('fs');
const path = require('path');

// TODO: Definir cores para diferentes níveis de log
const CORES = {
    INFO: '\x1b[36m',    // Ciano
    WARN: '\x1b[33m',    // Amarelo
    ERROR: '\x1b[31m',   // Vermelho
    SUCCESS: '\x1b[32m', // Verde
    RESET: '\x1b[0m'     // Reset das cores
};

// Níveis de log válidos
const NIVEIS_VALIDOS = ['INFO', 'WARN', 'ERROR', 'SUCCESS'];

// Diretório onde os logs serão salvos
const DIRETORIO_LOGS = path.join(__dirname, 'logs');

/**
 * TODO: Função para formatar timestamp
 * Retorna data e hora no formato: DD/MM/AAAA HH:MM:SS
 */
function formatarTimestamp() {
    const agora = new Date();
    
    const dia = agora.getDate().toString().padStart(2, '0');
    const mes = (agora.getMonth() + 1).toString().padStart(2, '0');
    const ano = agora.getFullYear();
    
    const horas = agora.getHours().toString().padStart(2, '0');
    const minutos = agora.getMinutes().toString().padStart(2, '0');
    const segundos = agora.getSeconds().toString().padStart(2, '0');
    
    return `${dia}/${mes}/${ano} ${horas}:${minutos}:${segundos}`;
}

/**
 * TODO: Função para obter nome do arquivo de log
 * Retorna nome no formato: app-AAAA-MM-DD.log
 */
function obterNomeArquivoLog() {
    const agora = new Date();
    
    const ano = agora.getFullYear();
    const mes = (agora.getMonth() + 1).toString().padStart(2, '0');
    const dia = agora.getDate().toString().padStart(2, '0');
    
    return `app-${ano}-${mes}-${dia}.log`;
}

/**
 * TODO: Função para criar diretório de logs se não existir
 */
function criarDiretorioLogs() {
    if (!fs.existsSync(DIRETORIO_LOGS)) {
        fs.mkdirSync(DIRETORIO_LOGS, { recursive: true });
        console.log(`📁 Diretório de logs criado: ${DIRETORIO_LOGS}`);
    }
}

/**
 * TODO: Função para validar mensagem e nível
 * Verifica se a mensagem não está vazia e se o nível é válido
 */
function validarLog(mensagem, nivel) {
    // Validar mensagem
    if (!mensagem || typeof mensagem !== 'string' || mensagem.trim() === '') {
        throw new Error('❌ Mensagem não pode estar vazia');
    }
    
    // Validar nível
    if (!nivel || !NIVEIS_VALIDOS.includes(nivel.toUpperCase())) {
        throw new Error(`❌ Nível inválido. Use: ${NIVEIS_VALIDOS.join(', ')}`);
    }
    
    return true;
}

/**
 * Função principal para registrar logs
 * Exibe no console com cores e salva em arquivo
 */
function log(mensagem, nivel = 'INFO') {
    try {
        // Validar entrada
        validarLog(mensagem, nivel);
        
        // Normalizar nível
        nivel = nivel.toUpperCase();
        
        // Criar diretório se necessário
        criarDiretorioLogs();
        
        // Formatar timestamp
        const timestamp = formatarTimestamp();
        
        // Formatar mensagem para console (com cores)
        const cor = CORES[nivel] || CORES.INFO;
        const mensagemConsole = `${cor}[${timestamp}] [${nivel}] ${mensagem}${CORES.RESET}`;
        
        // Formatar mensagem para arquivo (sem cores)
        const mensagemArquivo = `[${timestamp}] [${nivel}] ${mensagem}`;
        
        // Exibir no console
        console.log(mensagemConsole);
        
        // Salvar em arquivo
        const nomeArquivo = obterNomeArquivoLog();
        const caminhoArquivo = path.join(DIRETORIO_LOGS, nomeArquivo);
        
        fs.appendFileSync(caminhoArquivo, mensagemArquivo + '\n', 'utf8');
        
    } catch (error) {
        console.error(`❌ Erro ao registrar log: ${error.message}`);
    }
}

/**
 * Funções de conveniência para diferentes níveis
 */
function info(mensagem) {
    log(mensagem, 'INFO');
}

function warn(mensagem) {
    log(mensagem, 'WARN');
}

function error(mensagem) {
    log(mensagem, 'ERROR');
}

function success(mensagem) {
    log(mensagem, 'SUCCESS');
}

/**
 * TODO: Função para ler logs com filtros opcionais
 * Permite filtrar por data e/ou nível
 */
function lerLogs(opcoes = {}) {
    try {
        criarDiretorioLogs();
        
        const { data, nivel } = opcoes;
        let nomeArquivo;
        
        if (data) {
            // Se data específica foi fornecida, usar formato AAAA-MM-DD
            const dataFormatada = data.replace(/\//g, '-');
            nomeArquivo = `app-${dataFormatada}.log`;
        } else {
            // Usar arquivo do dia atual
            nomeArquivo = obterNomeArquivoLog();
        }
        
        const caminhoArquivo = path.join(DIRETORIO_LOGS, nomeArquivo);
        
        // Verificar se arquivo existe
        if (!fs.existsSync(caminhoArquivo)) {
            console.log(`📄 Arquivo de log não encontrado: ${nomeArquivo}`);
            return [];
        }
        
        // Ler conteúdo do arquivo
        const conteudo = fs.readFileSync(caminhoArquivo, 'utf8');
        let linhas = conteudo.split('\n').filter(linha => linha.trim() !== '');
        
        // Filtrar por nível se especificado
        if (nivel) {
            const nivelUpper = nivel.toUpperCase();
            linhas = linhas.filter(linha => linha.includes(`[${nivelUpper}]`));
        }
        
        return linhas;
        
    } catch (error) {
        console.error(`❌ Erro ao ler logs: ${error.message}`);
        return [];
    }
}

/**
 * Função para exibir logs formatados
 */
function exibirLogs(opcoes = {}) {
    const logs = lerLogs(opcoes);
    
    if (logs.length === 0) {
        console.log('📭 Nenhum log encontrado com os filtros especificados.');
        return;
    }
    
    console.log(`\n📋 Logs encontrados (${logs.length}):`);
    console.log('═'.repeat(60));
    
    logs.forEach((linha, index) => {
        // Extrair nível para colorir
        const match = linha.match(/\[(\w+)\]/g);
        if (match && match.length >= 2) {
            const nivel = match[1].replace(/[\[\]]/g, '');
            const cor = CORES[nivel] || CORES.RESET;
            console.log(`${cor}${index + 1}. ${linha}${CORES.RESET}`);
        } else {
            console.log(`${index + 1}. ${linha}`);
        }
    });
    
    console.log('═'.repeat(60));
}

/**
 * Função para listar todos os arquivos de log disponíveis
 */
function listarArquivosLog() {
    try {
        criarDiretorioLogs();
        
        const arquivos = fs.readdirSync(DIRETORIO_LOGS)
            .filter(arquivo => arquivo.endsWith('.log'))
            .sort();
        
        if (arquivos.length === 0) {
            console.log('📭 Nenhum arquivo de log encontrado.');
            return [];
        }
        
        console.log('\n📁 Arquivos de log disponíveis:');
        arquivos.forEach((arquivo, index) => {
            const caminhoCompleto = path.join(DIRETORIO_LOGS, arquivo);
            const stats = fs.statSync(caminhoCompleto);
            const tamanho = (stats.size / 1024).toFixed(2);
            console.log(`${index + 1}. ${arquivo} (${tamanho} KB)`);
        });
        
        return arquivos;
        
    } catch (error) {
        console.error(`❌ Erro ao listar arquivos: ${error.message}`);
        return [];
    }
}

// Exportar todas as funções
module.exports = {
    log,
    info,
    warn,
    error,
    success,
    lerLogs,
    exibirLogs,
    listarArquivosLog,
    formatarTimestamp,
    obterNomeArquivoLog,
    criarDiretorioLogs,
    validarLog,
    CORES,
    NIVEIS_VALIDOS,
    DIRETORIO_LOGS
};