// Crie função de soma
function somar(a, b) {
    return a + b;
}

// Crie função de subtração
function subtrair(a, b) {
    return a-b;
}

// Crie função de multiplicação
function multiplicar(a, b) {
    return a*b;
}

// Crie função de divisão com verificação de divisão por zero
function dividir(a, b) {
    // TODO: Verifique se b !== 0, senão retorne erro
    if (b === 0) {
        return 'Erro: Divisão por zero!';
    }
    return a/b;
}

// TODO: Teste todas as funções
const num1 = 10;
const num2 = 5;

console.log(num1+num2); 
console.log(num1-num2);
console.log(num1*num2);
console.log(num1/num2);
