// Dados em memória para arquivos (simulação)
let files = [
    {
        id: 1,
        filename: 'documento.pdf',
        originalName: 'Relatório Mensal.pdf',
        mimetype: 'application/pdf',
        size: 1024000, // 1MB em bytes
        userId: 1,
        uploadedAt: '2024-01-15T11:30:00.000Z',
        path: '/uploads/documento.pdf',
        description: 'Relatório mensal de vendas'
    },
    {
        id: 2,
        filename: 'imagem.jpg',
        originalName: 'Foto Perfil.jpg',
        mimetype: 'image/jpeg',
        size: 512000, // 512KB em bytes
        userId: 2,
        uploadedAt: '2024-01-16T15:20:00.000Z',
        path: '/uploads/imagem.jpg',
        description: 'Foto de perfil do usuário'
    },
    {
        id: 3,
        filename: 'planilha.xlsx',
        originalName: 'Dados Financeiros.xlsx',
        mimetype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        size: 2048000, // 2MB em bytes
        userId: 1,
        uploadedAt: '2024-01-17T10:15:00.000Z',
        path: '/uploads/planilha.xlsx',
        description: 'Planilha com dados financeiros'
    }
];

// Contador para gerar IDs únicos
let nextFileId = 4;

// Função para gerar próximo ID
function getNextFileId() {
    return nextFileId++;
}

// Função para encontrar arquivo por ID
function findFileById(id) {
    return files.find(file => file.id === parseInt(id));
}

// Função para encontrar arquivos por usuário
function findFilesByUserId(userId) {
    return files.filter(file => file.userId === parseInt(userId));
}

// Função para validar dados do arquivo
function validateFileData(fileData) {
    const errors = [];

    if (!fileData.filename || typeof fileData.filename !== 'string' || fileData.filename.trim().length < 1) {
        errors.push('Nome do arquivo é obrigatório');
    }

    if (!fileData.originalName || typeof fileData.originalName !== 'string') {
        errors.push('Nome original do arquivo é obrigatório');
    }

    if (!fileData.mimetype || typeof fileData.mimetype !== 'string') {
        errors.push('Tipo MIME é obrigatório');
    }

    if (!fileData.size || typeof fileData.size !== 'number' || fileData.size <= 0) {
        errors.push('Tamanho do arquivo deve ser um número positivo');
    }

    if (fileData.size > 10 * 1024 * 1024) { // 10MB limite
        errors.push('Arquivo muito grande (máximo 10MB)');
    }

    if (!fileData.userId || typeof fileData.userId !== 'number') {
        errors.push('ID do usuário é obrigatório');
    }

    return errors;
}

// Função para gerar nome único do arquivo
function generateUniqueFilename(originalName) {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8);
    const extension = originalName.split('.').pop();
    return `${timestamp}_${random}.${extension}`;
}

// Função para simular upload de arquivo
function uploadFile(fileData) {
    const errors = validateFileData(fileData);
    if (errors.length > 0) {
        throw new Error(errors.join(', '));
    }

    const newFile = {
        id: getNextFileId(),
        filename: generateUniqueFilename(fileData.originalName),
        originalName: fileData.originalName.trim(),
        mimetype: fileData.mimetype.toLowerCase(),
        size: fileData.size,
        userId: fileData.userId,
        uploadedAt: new Date().toISOString(),
        path: `/uploads/${generateUniqueFilename(fileData.originalName)}`,
        description: fileData.description || ''
    };

    files.push(newFile);
    return newFile;
}

// Função para deletar arquivo
function deleteFile(id) {
    const fileIndex = files.findIndex(file => file.id === parseInt(id));
    if (fileIndex === -1) {
        throw new Error('Arquivo não encontrado');
    }

    const deletedFile = files.splice(fileIndex, 1)[0];
    return deletedFile;
}

// Função para obter estatísticas dos arquivos
function getFileStats() {
    const totalSize = files.reduce((sum, file) => sum + file.size, 0);
    const mimetypes = [...new Set(files.map(file => file.mimetype))];
    
    return {
        total: files.length,
        totalSize: totalSize,
        totalSizeMB: Math.round(totalSize / (1024 * 1024) * 100) / 100,
        mimetypes: mimetypes,
        averageSize: files.length > 0 ? Math.round(totalSize / files.length) : 0,
        byMimetype: mimetypes.map(type => ({
            type,
            count: files.filter(file => file.mimetype === type).length
        }))
    };
}

// Função para filtrar arquivos
function filterFiles(filters = {}) {
    let filteredFiles = [...files];

    if (filters.userId) {
        filteredFiles = filteredFiles.filter(file => file.userId === parseInt(filters.userId));
    }

    if (filters.mimetype) {
        filteredFiles = filteredFiles.filter(file => 
            file.mimetype.toLowerCase().includes(filters.mimetype.toLowerCase())
        );
    }

    if (filters.minSize) {
        filteredFiles = filteredFiles.filter(file => file.size >= parseInt(filters.minSize));
    }

    if (filters.maxSize) {
        filteredFiles = filteredFiles.filter(file => file.size <= parseInt(filters.maxSize));
    }

    if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        filteredFiles = filteredFiles.filter(file => 
            file.originalName.toLowerCase().includes(searchTerm) ||
            file.description.toLowerCase().includes(searchTerm)
        );
    }

    return filteredFiles;
}

// Função para formatar tamanho do arquivo
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

module.exports = {
    files,
    getNextFileId,
    findFileById,
    findFilesByUserId,
    validateFileData,
    generateUniqueFilename,
    uploadFile,
    deleteFile,
    getFileStats,
    filterFiles,
    formatFileSize
};