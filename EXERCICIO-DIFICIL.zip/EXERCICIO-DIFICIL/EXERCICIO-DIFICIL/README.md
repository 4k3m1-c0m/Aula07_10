
npm install
  
**Iniciar o servidor:**
node server.js


**Acessar a API:**
   - URL base: `http://localhost:3000`
   - Status: `http://localhost:3000/status`

